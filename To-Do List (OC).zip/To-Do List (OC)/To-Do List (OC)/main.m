//
//  main.m
//  To-Do List (OC)
//
//  Created by Henry on 15/6/16.
//  Copyright © 2015年 Henry. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
