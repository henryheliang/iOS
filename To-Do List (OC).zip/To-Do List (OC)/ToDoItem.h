//
//  ToDoItem.h
//  To-Do List (OC)
//
//  Created by Henry on 15/6/16.
//  Copyright © 2015年 Henry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ToDoItem : NSObject

@property NSString  *strItemName;
@property BOOL      bCompleted;
@property (readonly) NSDate *dateCreation;



@end
