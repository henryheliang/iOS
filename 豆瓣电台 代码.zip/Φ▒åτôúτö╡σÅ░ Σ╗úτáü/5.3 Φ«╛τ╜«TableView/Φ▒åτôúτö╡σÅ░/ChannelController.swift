//
//  ChannelController.swift
//  豆瓣电台
//
//  Created by 东升 on 15/2/11.
//  Copyright (c) 2015年 85176878@qq.com. All rights reserved.
//

import UIKit

class ChannelController: UIViewController {

    //TableView控件 频道列表
    @IBOutlet weak var tv: UITableView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    //返回数据的行数
    func tableView(tableView: UITableView!, numberOfRowsInSection section: Int) -> Int{
        return 10
    }
    //设置cell
    func tableView(tableView: UITableView!, cellForRowAtIndexPath indexPath: NSIndexPath!) -> UITableViewCell!{
        //获取标示为“channel”的cell
        let cell=UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "channel")
        //设置标题
        cell.textLabel!.text = "title:\(indexPath.row)"
        //设置详情
        cell.detailTextLabel?.text = "detail:\(indexPath.row)"
        //返回cell
        return cell
    }
    //选择数据行响应方法
    func tableView(tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath!) {
        println("选择了第\(indexPath.row)行")
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
