//
//  ViewController.swift
//  豆瓣电台
//
//  Created by 东升 on 15/2/11.
//  Copyright (c) 2015年 85176878@qq.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    //ImageView控件 歌曲封面
    @IBOutlet weak var iv: UIImageView!
    //ProgressView控件 播放进度条
    @IBOutlet weak var progressView: UIProgressView!
    //Label控件 播放时间
    @IBOutlet weak var playTime: UILabel!
    //TableView控件 歌曲列表
    @IBOutlet weak var tv: UITableView!





    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    //返回数据的行数
    func tableView(tableView: UITableView!, numberOfRowsInSection section: Int) -> Int{
        return 10
    }
    //设置cell
    func tableView(tableView: UITableView!, cellForRowAtIndexPath indexPath: NSIndexPath!) -> UITableViewCell!{
        //获取标示为“douban”的cell
        let cell=UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "douban")
        //设置标题
        cell.textLabel!.text = "title:\(indexPath.row)"
        //设置详情
        cell.detailTextLabel?.text = "detail:\(indexPath.row)"
        //返回cell
        return cell
    }
    //选择数据行响应方法
    func tableView(tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath!) {
        println("选择了第\(indexPath.row)行")
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

