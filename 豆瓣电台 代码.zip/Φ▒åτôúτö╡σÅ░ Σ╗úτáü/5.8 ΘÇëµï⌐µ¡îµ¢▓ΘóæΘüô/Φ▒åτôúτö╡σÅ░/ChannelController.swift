//
//  ChannelController.swift
//  豆瓣电台
//
//  Created by 东升 on 15/2/11.
//  Copyright (c) 2015年 85176878@qq.com. All rights reserved.
//

import UIKit

//接收回传频道id参数的协议
protocol ChannelProtocol{
    func onChangeChannel(channel_id:String)
}

class ChannelController: UIViewController {

    //TableView控件 频道列表
    @IBOutlet weak var tv: UITableView!
    
    //频道列表数据
    var channelData:NSArray=NSArray()
    //遵循ChannelProtocol协议的代理
    var delegate:ChannelProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    //返回数据的行数
    func tableView(tableView: UITableView!, numberOfRowsInSection section: Int) -> Int{
        return channelData.count
    }
    //设置cell
    func tableView(tableView: UITableView!, cellForRowAtIndexPath indexPath: NSIndexPath!) -> UITableViewCell!{
        //获取标示为“channel”的cell
        let cell=UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "channel")
        //获取到选中的行的数据
        let rowData:NSDictionary=self.channelData[indexPath.row] as NSDictionary
        //设置tableView的标题
        cell.textLabel!.text = rowData["name"] as? String
        //返回cell
        return cell
    }

    //选中了具体的频道
    func tableView(tableView: UITableView!, didSelectRowAtIndexPath indexPath: NSIndexPath!) {
        println("选择了第\(indexPath.row)行")
        var rowData:NSDictionary=self.channelData[indexPath.row] as NSDictionary
        //获取选择的频道id
        let channel_id:AnyObject? = rowData["channel_id"] as AnyObject?
        //将AnyObject转为String
        let channel:String="channel=\(channel_id!)"
        //将频道id传回给主界面
        delegate?.onChangeChannel(channel)
        //关闭当前界面
        self.dismissViewControllerAnimated(true, completion: nil)
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
