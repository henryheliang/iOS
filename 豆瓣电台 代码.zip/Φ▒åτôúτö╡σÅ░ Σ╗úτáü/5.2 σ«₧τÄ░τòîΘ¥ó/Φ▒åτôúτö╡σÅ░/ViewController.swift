//
//  ViewController.swift
//  豆瓣电台
//
//  Created by 东升 on 15/2/11.
//  Copyright (c) 2015年 85176878@qq.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    //ImageView控件 歌曲封面
    @IBOutlet weak var iv: UIImageView!
    //ProgressView控件 播放进度条
    @IBOutlet weak var progressView: UIProgressView!
    //Label控件 播放时间
    @IBOutlet weak var playTime: UILabel!
    //TableView控件 歌曲列表
    @IBOutlet weak var tv: UITableView!





    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

