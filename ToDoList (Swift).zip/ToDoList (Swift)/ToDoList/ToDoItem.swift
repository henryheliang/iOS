//
//  ToDoItem.swift
//  ToDoList
//
//  Created by Henry on 15/6/17.
//  Copyright © 2015年 Henry. All rights reserved.
//

import UIKit

class ToDoItem: NSObject {
    
    var completed:Bool = false
    var itemName:NSString?
    var createDate:NSDate!

}
